module Observer
  VERSION = "0.1.0"
end
