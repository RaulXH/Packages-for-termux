# frozen_string_literal: true

class Matrix
  VERSION = "0.2.0"
end
