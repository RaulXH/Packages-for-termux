#
# $Id: 8ab2cb5341529fe5e35956bb1a1f42ec9b9c6f5a $
#
# Copyright (c) 1999-2006 Minero Aoki
#
# This program is free software.
# You can distribute/modify this program under the same terms of ruby.
# see the file "COPYING".

module Racc
  VERSION   = '1.4.16'
  Version = VERSION
  Copyright = 'Copyright (c) 1999-2006 Minero Aoki'
end
